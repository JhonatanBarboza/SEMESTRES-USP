        float precisao = 1.0; // Precisão desejada
        float estimativa = num / 2.0;
        float diferenca;

        do {
            float nova_estimativa = (estimativa + num / estimativa) / 2.0;
            diferenca = estimativa - nova_estimativa;
            estimativa = nova_estimativa;
        } while (diferenca > precisao || diferenca < -precisao);

        return estimativa;







        if (num < 0) {
        return -1; // Retorna -1 para números negativos
    }

    int i = 0;
    while (i * i <= num) {
        if (i * i == num) {
            return i; // Retorna a raiz quadrada exata
        }
        i++;
    }
    return -1; // Retorna -1 se o número não for um quadrado perfeito