import bozo

def main():
    bozo.Bozo.main()

if __name__ == "__main__":
    main()